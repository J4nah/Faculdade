/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repaginando;

import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class Autor {
    private String nome;
    private ArrayList<Livro> listaLivros;
    
    //-----------------------------------

    public Autor() {
        this.listaLivros = new ArrayList();
    }

    public Autor(String nome) {
        this.nome = nome;
        this.listaLivros = new ArrayList();
    }

    //++++++++++++++++++
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Livro> getListaLivros() {
        return listaLivros;
    }

    public void setListaLivros(ArrayList<Livro> listaLivros) {
        this.listaLivros = listaLivros;
    }
    
    //-----------------------
    
    public void adicionarLivros(Livro l){
    listaLivros.add(l);
    }
    
     public void removerLivros(Livro l){
    listaLivros.remove(l);
    }
    
}
