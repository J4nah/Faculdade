/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repaginando;

import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class Genero {
    private String nome;
    private int id;
    
//-------------------------------------------------    
    
    public Genero() {
    }

    public Genero(String nome, int id) {
        this.nome = nome;
        this.id = id;
    }
    
    //+++++++++++++++++++++++++
    
   //definir o nome do genero
    public void setNome(String nome){
        this.nome = nome;
    }
    
    //obter nome do genero
    public String getNome(){
        return nome;
    }
    
    public void criarGenero(String nome){
        Genero novoGenero = new Genero();
        
        
    } 
    
  
    
}
