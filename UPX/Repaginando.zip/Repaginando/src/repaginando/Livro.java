/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repaginando;

import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class Livro {
    private String nome;
    private String autor;
    private String editora;
    private int codigo;
    private int anoPubli;
    private ArrayList<Genero> generoLivro;

    //----------------------------------
    public Livro() {
       this. generoLivro = new ArrayList();
    }

    public Livro(String nome, String autor, String editora, int codigo, int anoPubli) {
        this.nome = nome;
        this.autor = autor;
        this.editora = editora;
        this.codigo = codigo;
        this.anoPubli = anoPubli;
      this.generoLivro = new ArrayList();
    }
    
    //+++++++++++++++++++++++++
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getAnoPubli() {
        return anoPubli;
    }

    public void setAnoPubli(int anoPubli) {
        this.anoPubli = anoPubli;
    }

    public ArrayList<Genero> getGeneroLivros() {
        return generoLivro;
    }

    public void setGeneroLivros(ArrayList<Genero> livroGeneros) {
        this.generoLivro = livroGeneros;
    }

   
    
    
    
    
    
}
