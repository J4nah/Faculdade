/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repaginando;

import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class Usuario {
    private String nome;
    private int idade;
    private String logradouro;
    private String uf;
    private String email;
    private String telefone;
    private ArrayList<Genero> generosInteresse;
    
    //--------------------------------

    public Usuario() {
        this.generosInteresse = new ArrayList();
    }

    public Usuario(String nome, int idade, String logradouro, String uf, String email, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.logradouro = logradouro;
        this.uf = uf;
        this.email = email;
        this.telefone = telefone;
        this.generosInteresse = new ArrayList();
        
    }
    
    //++++++++++++++++++++++

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public ArrayList<Genero> getGenerosInteresse() {
        return generosInteresse;
    }

    public void setGenerosInteresse(ArrayList<Genero> generosInteresse) {
        this.generosInteresse = generosInteresse;
    }
    
    //--------------------------------------------------
    
    public void adicionarGeneroInteresse(Genero g){
        generosInteresse.add(g);
    }
    
    public void removerGeneroInteresse(Genero g){
        generosInteresse.remove(g);
    }
    
}
